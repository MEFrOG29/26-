﻿namespace LabWork_26
{
    partial class Plane
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ComingOutTextBox = new TextBox();
            ComingToTextBox = new TextBox();
            ComingOutLabel = new Label();
            ComingToLabel = new Label();
            DateOutLabel = new Label();
            DateToLabel = new Label();
            OutDateTimePicker1 = new DateTimePicker();
            ToDateTimePicker2 = new DateTimePicker();
            PayButton = new Button();
            SuspendLayout();
            // 
            // ComingOutTextBox
            // 
            ComingOutTextBox.Location = new Point(33, 64);
            ComingOutTextBox.Name = "ComingOutTextBox";
            ComingOutTextBox.Size = new Size(125, 27);
            ComingOutTextBox.TabIndex = 0;
            // 
            // ComingToTextBox
            // 
            ComingToTextBox.Location = new Point(33, 167);
            ComingToTextBox.Name = "ComingToTextBox";
            ComingToTextBox.Size = new Size(125, 27);
            ComingToTextBox.TabIndex = 1;
            // 
            // ComingOutLabel
            // 
            ComingOutLabel.AutoSize = true;
            ComingOutLabel.Location = new Point(33, 41);
            ComingOutLabel.Name = "ComingOutLabel";
            ComingOutLabel.Size = new Size(56, 20);
            ComingOutLabel.TabIndex = 4;
            ComingOutLabel.Text = "Откуда";
            // 
            // ComingToLabel
            // 
            ComingToLabel.AutoSize = true;
            ComingToLabel.Location = new Point(37, 144);
            ComingToLabel.Name = "ComingToLabel";
            ComingToLabel.Size = new Size(41, 20);
            ComingToLabel.TabIndex = 5;
            ComingToLabel.Text = "Куда";
            // 
            // DateOutLabel
            // 
            DateOutLabel.AutoSize = true;
            DateOutLabel.Location = new Point(267, 41);
            DateOutLabel.Name = "DateOutLabel";
            DateOutLabel.Size = new Size(89, 20);
            DateOutLabel.TabIndex = 6;
            DateOutLabel.Text = "Во сколько:";
            // 
            // DateToLabel
            // 
            DateToLabel.AutoSize = true;
            DateToLabel.Location = new Point(267, 144);
            DateToLabel.Name = "DateToLabel";
            DateToLabel.Size = new Size(89, 20);
            DateToLabel.TabIndex = 7;
            DateToLabel.Text = "Во сколько:";
            // 
            // OutDateTimePicker1
            // 
            OutDateTimePicker1.Location = new Point(274, 64);
            OutDateTimePicker1.Name = "OutDateTimePicker1";
            OutDateTimePicker1.Size = new Size(250, 27);
            OutDateTimePicker1.TabIndex = 8;
            // 
            // ToDateTimePicker2
            // 
            ToDateTimePicker2.Location = new Point(274, 167);
            ToDateTimePicker2.Name = "ToDateTimePicker2";
            ToDateTimePicker2.ShowCheckBox = true;
            ToDateTimePicker2.Size = new Size(250, 27);
            ToDateTimePicker2.TabIndex = 9;
            // 
            // PayButton
            // 
            PayButton.Location = new Point(630, 372);
            PayButton.Name = "PayButton";
            PayButton.Size = new Size(94, 29);
            PayButton.TabIndex = 10;
            PayButton.Text = "Заказать";
            PayButton.UseVisualStyleBackColor = true;
            PayButton.Click += PayButton_Click;
            // 
            // Plane
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(PayButton);
            Controls.Add(ToDateTimePicker2);
            Controls.Add(OutDateTimePicker1);
            Controls.Add(DateToLabel);
            Controls.Add(DateOutLabel);
            Controls.Add(ComingToLabel);
            Controls.Add(ComingOutLabel);
            Controls.Add(ComingToTextBox);
            Controls.Add(ComingOutTextBox);
            Name = "Plane";
            Text = "Plane";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox ComingOutTextBox;
        private TextBox ComingToTextBox;
        private Label ComingOutLabel;
        private Label ComingToLabel;
        private Label DateOutLabel;
        private Label DateToLabel;
        private DateTimePicker OutDateTimePicker1;
        private DateTimePicker ToDateTimePicker2;
        private Button PayButton;
    }
}