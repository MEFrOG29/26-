﻿namespace LabWork_26
{
    partial class CalcForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            NumberTextBox1 = new TextBox();
            NumberTextBox2 = new TextBox();
            AddRadioButton = new RadioButton();
            MinusRadioButton = new RadioButton();
            MultiplyRadioButton = new RadioButton();
            DivideRadioButton = new RadioButton();
            EvenlyLabel = new Label();
            ResponseLabel = new Label();
            ResponseButton = new Button();
            SuspendLayout();
            // 
            // NumberTextBox1
            // 
            NumberTextBox1.Location = new Point(15, 207);
            NumberTextBox1.Name = "NumberTextBox1";
            NumberTextBox1.Size = new Size(125, 27);
            NumberTextBox1.TabIndex = 0;
            NumberTextBox1.KeyPress += NumberTextBox1_KeyPress;
            // 
            // NumberTextBox2
            // 
            NumberTextBox2.Location = new Point(348, 214);
            NumberTextBox2.Name = "NumberTextBox2";
            NumberTextBox2.Size = new Size(125, 27);
            NumberTextBox2.TabIndex = 1;
            // 
            // AddRadioButton
            // 
            AddRadioButton.AutoSize = true;
            AddRadioButton.Location = new Point(221, 166);
            AddRadioButton.Name = "AddRadioButton";
            AddRadioButton.Size = new Size(40, 24);
            AddRadioButton.TabIndex = 2;
            AddRadioButton.TabStop = true;
            AddRadioButton.Text = "+";
            AddRadioButton.UseVisualStyleBackColor = true;
            
            // 
            // MinusRadioButton
            // 
            MinusRadioButton.AutoSize = true;
            MinusRadioButton.Location = new Point(221, 196);
            MinusRadioButton.Name = "MinusRadioButton";
            MinusRadioButton.Size = new Size(36, 24);
            MinusRadioButton.TabIndex = 2;
            MinusRadioButton.TabStop = true;
            MinusRadioButton.Text = "-";
            MinusRadioButton.UseVisualStyleBackColor = true;
            
            // 
            // MultiplyRadioButton
            // 
            MultiplyRadioButton.AutoSize = true;
            MultiplyRadioButton.Location = new Point(221, 227);
            MultiplyRadioButton.Name = "MultiplyRadioButton";
            MultiplyRadioButton.Size = new Size(36, 24);
            MultiplyRadioButton.TabIndex = 2;
            MultiplyRadioButton.TabStop = true;
            MultiplyRadioButton.Text = "*";
            MultiplyRadioButton.UseVisualStyleBackColor = true;
            // 
            // DivideRadioButton
            // 
            DivideRadioButton.AutoSize = true;
            DivideRadioButton.Location = new Point(221, 257);
            DivideRadioButton.Name = "DivideRadioButton";
            DivideRadioButton.Size = new Size(36, 24);
            DivideRadioButton.TabIndex = 2;
            DivideRadioButton.TabStop = true;
            DivideRadioButton.Text = "/";
            DivideRadioButton.UseVisualStyleBackColor = true;
            // 
            // EvenlyLabel
            // 
            EvenlyLabel.AutoSize = true;
            EvenlyLabel.Location = new Point(514, 217);
            EvenlyLabel.Name = "EvenlyLabel";
            EvenlyLabel.Size = new Size(19, 20);
            EvenlyLabel.TabIndex = 3;
            EvenlyLabel.Text = "=";
            // 
            // ResponseLabel
            // 
            ResponseLabel.AutoSize = true;
            ResponseLabel.Location = new Point(605, 221);
            ResponseLabel.Name = "ResponseLabel";
            ResponseLabel.Size = new Size(0, 20);
            ResponseLabel.TabIndex = 5;
            // 
            // ResponseButton
            // 
            ResponseButton.Location = new Point(562, 285);
            ResponseButton.Name = "ResponseButton";
            ResponseButton.Size = new Size(94, 29);
            ResponseButton.TabIndex = 6;
            ResponseButton.Text = "Вычислить";
            ResponseButton.UseVisualStyleBackColor = true;
            ResponseButton.Click += ResponseButton_Click;
            // 
            // CalcForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(ResponseButton);
            Controls.Add(ResponseLabel);
            Controls.Add(EvenlyLabel);
            Controls.Add(DivideRadioButton);
            Controls.Add(MultiplyRadioButton);
            Controls.Add(MinusRadioButton);
            Controls.Add(AddRadioButton);
            Controls.Add(NumberTextBox2);
            Controls.Add(NumberTextBox1);
            Name = "CalcForm";
            Text = "CalcForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox NumberTextBox1;
        private TextBox NumberTextBox2;
        private RadioButton AddRadioButton;
        private RadioButton MinusRadioButton;
        private RadioButton MultiplyRadioButton;
        private RadioButton DivideRadioButton;
        private Label EvenlyLabel;
        private Label ResponseLabel;
        private Button ResponseButton;
    }
}