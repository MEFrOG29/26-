﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabWork_26
{
    public partial class CalcForm : Form
    {
        public CalcForm()
        {
            InitializeComponent();
        }
        private void NumberTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
        }



        private void ResponseButton_Click(object sender, EventArgs e)
        {
            
            if (AddRadioButton.Checked == true)
            {
                ResponseLabel.Text = (Convert.ToDouble(NumberTextBox1.Text) + Convert.ToInt32(NumberTextBox2.Text)).ToString();
            }
            if (MinusRadioButton.Checked == true)
            {
                ResponseLabel.Text = (Convert.ToDouble(NumberTextBox1.Text) - Convert.ToInt32(NumberTextBox2.Text)).ToString();
            }
            if (MultiplyRadioButton.Checked == true)
            {
                ResponseLabel.Text = (Convert.ToDouble(NumberTextBox1.Text) * Convert.ToInt32(NumberTextBox2.Text)).ToString();
            }
            if (DivideRadioButton.Checked == true)
            {
                ResponseLabel.Text = (Convert.ToDouble(NumberTextBox1.Text) / Convert.ToInt32(NumberTextBox2.Text)).ToString();
            }
        }
    }
}
