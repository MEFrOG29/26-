﻿namespace LabWork_26
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TransitionForAuthorisationButton = new Button();
            TransitionForCalcButton = new Button();
            PlaneButton = new Button();
            SuspendLayout();
            // 
            // TransitionForAuthorisationButton
            // 
            TransitionForAuthorisationButton.Location = new Point(62, 124);
            TransitionForAuthorisationButton.Name = "TransitionForAuthorisationButton";
            TransitionForAuthorisationButton.Size = new Size(130, 127);
            TransitionForAuthorisationButton.TabIndex = 0;
            TransitionForAuthorisationButton.Text = "Авторизация";
            TransitionForAuthorisationButton.UseVisualStyleBackColor = true;
            TransitionForAuthorisationButton.Click += TransitionForAuthorisationButton_Click;
            // 
            // TransitionForCalcButton
            // 
            TransitionForCalcButton.Location = new Point(282, 124);
            TransitionForCalcButton.Name = "TransitionForCalcButton";
            TransitionForCalcButton.Size = new Size(124, 127);
            TransitionForCalcButton.TabIndex = 1;
            TransitionForCalcButton.Text = "Калькулятор";
            TransitionForCalcButton.UseVisualStyleBackColor = true;
            TransitionForCalcButton.Click += TransitionForCalcButton_Click;
            // 
            // PlaneButton
            // 
            PlaneButton.Location = new Point(534, 124);
            PlaneButton.Name = "PlaneButton";
            PlaneButton.Size = new Size(136, 127);
            PlaneButton.TabIndex = 2;
            PlaneButton.Text = "Билеты на самолет";
            PlaneButton.UseVisualStyleBackColor = true;
            PlaneButton.Click += PlaneButton_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(PlaneButton);
            Controls.Add(TransitionForCalcButton);
            Controls.Add(TransitionForAuthorisationButton);
            Name = "MainForm";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button TransitionForAuthorisationButton;
        private Button TransitionForCalcButton;
        private Button PlaneButton;
    }
}
