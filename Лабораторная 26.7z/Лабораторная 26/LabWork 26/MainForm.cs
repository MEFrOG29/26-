namespace LabWork_26
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void TransitionForAuthorisationButton_Click(object sender, EventArgs e)
        {
            AuthorizationForm form = new AuthorizationForm();
            form.ShowDialog();
        }

        private void TransitionForCalcButton_Click(object sender, EventArgs e)
        {
            CalcForm form = new CalcForm();
            form.ShowDialog();
        }

        private void PlaneButton_Click(object sender, EventArgs e)
        {
            Plane form = new Plane();
            form.ShowDialog();
        }
    }
}
