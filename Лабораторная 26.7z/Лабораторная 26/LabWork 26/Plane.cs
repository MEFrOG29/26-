﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabWork_26
{
    public partial class Plane : Form
    {
        public Plane()
        {
            InitializeComponent();
        }

        private void PayButton_Click(object sender, EventArgs e)
        {
            if (ToDateTimePicker2.Checked == false)
                MessageBox.Show($"Билет: {OutDateTimePicker1.Value.ToShortDateString()} {ComingOutTextBox.Text} {ComingToTextBox.Text}");
            else
            {
                MessageBox.Show($"Билет: {OutDateTimePicker1.Value.ToShortDateString()} {ComingOutTextBox.Text} {ComingToTextBox.Text} \n Обратный билет: {ToDateTimePicker2.Value.ToShortDateString()} {ComingToTextBox.Text} {ComingOutTextBox.Text}");
            }
        }
    }
}
